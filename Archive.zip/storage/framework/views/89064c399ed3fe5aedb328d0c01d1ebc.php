<header id="ritekhela-header" class="ritekhela-header-one">
            
    <!--// TopStrip //-->
    <div class="ritekhela-topstrip">
        <div class="container">
            <div class="row">
                
                <aside class="col-md-6">
                    <strong><?php echo e(__('header.Latest_News')); ?> :</strong>
                    <div class="ritekhela-latest-news-slider">
                        <div class="ritekhela-latest-news-slider-layer">Welcome visitor you can Login or Create an Account </div>
                        <div class="ritekhela-latest-news-slider-layer">While familiar with fellow European nation France Hareide. </div>
                    </div>
                </aside>
                <aside class="col-md-6">
                    <ul class="ritekhela-user-strip">
                        <li><a href="#"><i class="fa fa-globe-asia"></i> Support</a></li>
                        <li><a href="#"><i class="fa fa-dollar-sign"></i> Currency : USD</a></li>
                        <li>
                            <select class="form-control Langchange">
                                <option value="en" <?php echo e(session()->get('locale') == 'en' ? 'selected' : ''); ?>>English</option>
                                <option value="fr" <?php echo e(session()->get('locale') == 'fr' ? 'selected' : ''); ?>>Francais</option>                    
                            </select>
                        </li>
                        <li><a href="#" data-toggle="modal" data-target="#ritekhelamodalcenter"><i class="fa fa-user-alt"></i> Login</a></li>
                        <li><a href="#" data-toggle="modal" data-target="#ritekhelamodalrg"><i class="fa fa-sign-in-alt"></i> Signup</a></li>
                    </ul>
                </aside>
            </div>
        </div>
    </div>
    <!--// TopStrip //-->
    
    <!--// Main Header //-->
    <div class="ritekhela-main-header">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <a href="index-2.html" class="ritekhela-logo"><img src="<?php echo e(asset('images/logo.png')); ?>" alt=""></a>
                    <div class="ritekhela-right-section">
                        <div class="ritekhela-navigation">
                            <span class="ritekhela-menu-link">
                                <span class="menu-bar"></span>
                                <span class="menu-bar"></span>
                                <span class="menu-bar"></span>
                            </span>
                            <nav id="main-nav">
                                <ul id="main-menu" class="sm sm-blue">
                                    <li class="active"><a href="<?php echo e(route('main')); ?>"><?php echo e(__('header.home')); ?></a></li>
                                    
                                    <li><a href="<?php echo e(route('players.index')); ?>"><?php echo e(__('header.players')); ?></a></li>
                                    <li><a href="<?php echo e(route('teams.index')); ?>"><?php echo e(__('header.teams')); ?></a></li>
                                    <li><a href="<?php echo e(route('stadium.index')); ?>"><?php echo e(__('header.stadium')); ?></a></li>
                                    
                                    <li><a href="contact-us.html">Contact Us</a></li>
                                </ul>
                            </nav>
                        </div>
                        <ul class="ritekhela-navsearch">
                            <li><a href="#" class="ritekhela-open-cart"><i class="fab fa-opencart"></i></a>
                                <div class="ritekhela-cart-box">
                                    <h2>You have 3 items in the cart</h2>
                                    <ul>
                                        <li>
                                            <figure><a href="#"><img src="<?php echo e(asset('extra-images/cartbox-1.png')); ?>" alt=""></a></figure>
                                            <div class="ritekhela-cartbox-text">
                                                <h6><a href="#">Key Management Model The 60+ Models</a></h6>
                                                <div class="ritekhela-rating"><span class="ritekhela-rating-box half-width"></span></div>
                                                <span class="ritekhela-cartbox-price ritekhela-color-two">$35.99 <small>$43.00</small></span>
                                            </div>
                                        </li>
                                        <li>
                                            <figure><a href="#"><img src="<?php echo e(asset('extra-images/cartbox-2.png')); ?>" alt=""></a></figure>
                                            <div class="ritekhela-cartbox-text">
                                                <h6><a href="#">Pyramid Principle: Logic Writing &amp; Thinking</a></h6>
                                                <div class="ritekhela-rating"><span class="ritekhela-rating-box half-width"></span></div>
                                                <span class="ritekhela-cartbox-price ritekhela-color-two">$21.00</span>
                                            </div>
                                        </li>
                                    </ul>
                                    <h5>Subtotal <span class="ritekhela-color-two">$1343</span></h5>
                                    <div class="ritekhela-cart-link"><a href="#" class="ritekhela-cartbox-btn">Go to Checkout</a></div>
                                </div>
                            </li>
                            <li><a href="#" data-toggle="modal" data-target="#ritekhelamodalsearch"><i class="fa fa-search"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--// Main Header //-->

</header><?php /**PATH /Users/mac/Desktop/Safsaf/Laravel/FootLovers/resources/views/front/layouts/header.blade.php ENDPATH**/ ?>