<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"><a
                    href="<?php echo e(route('admin.players.index')); ?>"><?php echo e(__('breadcrumbs.player')); ?></a> /</span> Account</h4>
        <?php if(Session::has('success')): ?>
            <div class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?> alert-dismissible" role="alert">
                <?php echo e(Session::get('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <div class="row">
            <div class="col-md-12">
                <div class="card mb-4">
                    <h5 class="card-header">Profile Details</h5>
                    <hr class="my-0" />
                    <div class="card-body">
                        <form id="formAccountSettings" method="POST"
                            action="<?php echo e(route('admin.player.update', $player->slug)); ?>">
                            <input type="hidden" name="_method" value="PUT">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <div class="row">
                                <div class="mb-3 col-md-4">
                                    <label for="firstName" class="form-label"><?php echo e(__('spans.first_name')); ?></label>
                                    <input class="form-control" type="text" id="firstName" name="firstName"
                                        value="<?php echo e($player->firstname); ?>" autofocus />
                                </div>
                                <div class="mb-3 col-md-4">
                                    <label for="lastName" class="form-label"><?php echo e(__('spans.last_name')); ?></label>
                                    <input class="form-control" type="text" name="lastName" id="lastName"
                                        value="<?php echo e($player->lastname); ?>" />
                                </div>
                                <div class="mb-3 col-md-4">
                                    <label for="fullName" class="form-label"><?php echo e(__('spans.full_name')); ?></label>
                                    <input class="form-control" type="text" name="fullName" id="fullName"
                                        value="<?php echo e($player->fullname); ?>" />
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label for="displayName" class="form-label"><?php echo e(__('spans.display_name')); ?></label>
                                    <input class="form-control" type="text" id="displayName" name="displayName"
                                        value="<?php echo e($player->display_name); ?>" />
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label for="shirtNumber" class="form-label"><?php echo e(__('spans.shirt_number')); ?></label>
                                    <input type="text" class="form-control" id="shirtNumber" name="shirtNumber"
                                        value="<?php echo e($player->shirt_number); ?>" />
                                </div>
                                <div class="mb-3 col-md-3">
                                    <label class="form-label" for="nationality"><?php echo e(__('spans.nationality')); ?></label>
                                    <div class="input-group input-group-merge">
                                        <input type="text" id="nationality" name="nationality" class="form-control"
                                            value="<?php echo e($player->nationality); ?>" />
                                    </div>
                                </div>
                                <div class="mb-3 col-md-3">
                                    <label for="birthdate" class="form-label"><?php echo e(__('spans.birthdate')); ?></label>
                                    <input type="text" class="form-control" id="birthdate" name="birthdate"
                                        value="<?php echo e($player->birthdate); ?>" />
                                </div>
                                <div class="mb-3 col-md-3">
                                    <label for="birthcountry" class="form-label"><?php echo e(__('spans.birthcountry')); ?></label>
                                    <input class="form-control" type="text" id="birthcountry" name="birthcountry"
                                        value="<?php echo e($player->birthcountry); ?>" />
                                </div>
                                <div class="mb-3 col-md-3">
                                    <label for="birthplace" class="form-label"><?php echo e(__('spans.birthplace')); ?></label>
                                    <input type="text" class="form-control" id="birthplace" name="birthplace"
                                        value="<?php echo e($player->birthplace); ?>" />
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label class="form-label" for="team_id"><?php echo e(__('spans.team')); ?></label>
                                    <select id="team_id" name="team_id" class="select2 form-select">
                                        <option value=""><?php echo e(__('spans.select')); ?></option>
                                        <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"
                                                <?php if($player->team_id == $item->id): ?> selected <?php endif; ?>><?php echo e($item->name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label for="league_id" class="form-label"><?php echo e(__('spans.league')); ?></label>
                                    <select id="league_id" name="league_id" class="select2 form-select">
                                        <option value=""><?php echo e(__('spans.select')); ?></option>
                                        <?php $__currentLoopData = $leagues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"
                                                <?php if($player->league_id == $item->id): ?> selected <?php endif; ?>><?php echo e($item->name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label for="country_id" class="form-label"><?php echo e(__('spans.country')); ?></label>
                                    <select id="country_id" name="country_id" class="select2 form-select">
                                        <option value=""><?php echo e(__('spans.select')); ?></option>
                                        <?php $__currentLoopData = $countrys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"
                                                <?php if($player->country_id == $item->id): ?> selected <?php endif; ?>><?php echo e($item->name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label for="position_id" class="form-label"><?php echo e(__('spans.position')); ?></label>
                                    <select id="position_id" name="position_id" class="select2 form-select">
                                        <option value=""><?php echo e(__('spans.select')); ?></option>
                                        <?php $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"
                                                <?php if($player->position_id == $item->id): ?> selected <?php endif; ?>><?php echo e($item->name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="mb-3 col-md-4">
                                    <label for="height" class="form-label"><?php echo e(__('spans.height')); ?></label>
                                    <input class="form-control" type="text" id="height" name="height"
                                        value="<?php echo e($player->height); ?>" autofocus />
                                </div>
                                <div class="mb-3 col-md-4">
                                    <label for="weight" class="form-label"><?php echo e(__('spans.weight')); ?></label>
                                    <input class="form-control" type="text" name="weight" id="weight"
                                        value="<?php echo e($player->weight); ?>" />
                                </div>
                                <div class="mb-3 col-md-4">
                                    <label for="image" class="form-label"><?php echo e(__('spans.image')); ?></label>
                                    <input class="form-control" type="text" name="image" id="image"
                                        value="<?php echo e($player->image_path); ?>" />
                                </div>
                            </div>
                            <div class="mt-2">
                                <button type="submit"
                                    class="btn btn-primary me-2"><?php echo e(__('btns.save_changes')); ?></button>
                                <button type="reset" class="btn btn-outline-secondary"><?php echo e(__('btns.cancel')); ?></button>
                            </div>
                        </form>
                    </div>
                    <!-- /Account -->
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('back.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mac/Desktop/Safsaf/Laravel/FootLovers/resources/views/back/player/edit.blade.php ENDPATH**/ ?>