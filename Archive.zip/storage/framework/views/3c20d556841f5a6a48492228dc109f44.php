<!doctype html>
<html lang="zxx">


<!--  36:22-->
<head>

    <!-- meta tags -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <title>Sports & Magazine Khela</title>

    <!-- CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/fontawesome-all.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/slick-slider.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/fancybox.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/smartmenus.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/color.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/responsive.css')); ?>">
</head>

<body class="home">
    <div id="ritekhela-loader">
        <div id="ritekhela-loader-inner">
            <div id="ritekhela-shadow"></div>
            <div id="ritekhela-box"></div>
        </div>
    </div>

    <div class="ritekhela-wrapper">
        <?php echo $__env->make('front.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('banner'); ?>
        
        <?php echo $__env->yieldContent('subheader'); ?>
        <div class="ritekhela-main-content">

        <?php echo $__env->yieldContent('content'); ?>
        </div>
        <?php echo $__env->make('front.layouts.extra', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('front.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>
    <!-- .site-wrap -->

    <script src="<?php echo e(asset('script/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('script/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('script/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('script/slick.slider.min.js')); ?>"></script>
    <script src="<?php echo e(asset('script/fancybox.min.js')); ?>"></script>
    <script src="<?php echo e(asset('script/isotope.min.js')); ?>"></script>
    <script src="<?php echo e(asset('script/smartmenus.min.js')); ?>"></script>
    <script src="<?php echo e(asset('script/progressbar.js')); ?>"></script>
    <script src="<?php echo e(asset('script/jquery.countdown.min.js')); ?>"></script>
    <script src="<?php echo e(asset('script/functions.js')); ?>"></script>
</body>

<script type="text/javascript">  
    var url = "<?php echo e(route('LangChange')); ?>";
    $(".Langchange").change(function(){
        window.location.href = url + "?lang="+ $(this).val();
    });  
</script>
</html>
<?php /**PATH /Users/mac/Desktop/Safsaf/Laravel/FootLovers/resources/views/front/layouts/app.blade.php ENDPATH**/ ?>