<?php $__env->startSection('title', 'Vacation'); ?>

<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('subheader'); ?>
    <!--// SubHeader //-->
    <div class="ritekhela-subheader">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1>Player Grid</h1>
                    <ul class="ritekhela-breadcrumb">
                        <li><a href="#">Home</a></li>
                        <li><a href="#">Player</a></li>
                        <li>Player Grid</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!--// SubHeader //-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="ritekhela-main-section ritekhela-fixture-list-full">
    <div class="container">
        <div class="row">
            
            <!--// Full Section //-->
            <div class="col-md-12">
                <!--// Player //-->
                <div class="ritekhela-team ritekhela-team-view1">
                    <ul class="row">
                        <?php $__currentLoopData = $stadiums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="col-md-3">
                            <figure>
                                <a href="#"><img src="<?php echo e($item->image_path); ?>" alt=""></a>
                                <figcaption>
                                    <a href="#" class="fab fa-facebook-f"></a>
                                    <a href="#" class="fab fa-twitter"></a>
                                    <a href="#" class="fab fa-instagram"></a>
                                    <a href="#" class="fab fa-dribbble"></a>
                                </figcaption>
                            </figure>
                            <div class="ritekhela-team-view1-text">
                                <h2><a href="<?php echo e(route('stadium.details',['slug'=>$item->slug])); ?>"><?php echo e($item->name); ?></a></h2>
                                <span><?php echo e($item->league); ?></span>
                                <p><?php echo e($item->team->name); ?></p>
                            </div>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </ul>
                </div>
                <!--// Player //-->
                <!--// Pagination //-->
                <div class="ritekhela-pagination">
                    <ul>
                        <li><a href="#"><i class="fa fa-angle-left"></i></a></li>
                        <li><a href="#">1</a></li>
                        <li><a href="#">2</a></li>
                        <li><a href="#">3</a></li>
                        <li><a href="#">4</a></li>
                        <li><a href="#">5</a></li>
                        <li><a href="#"><i class="fa fa-angle-right"></i></a></li>
                    </ul>
                </div>
                <!--// Pagination //-->
            </div>
            <!--// Full Section //-->
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mac/Desktop/Safsaf/Laravel/FootLovers/resources/views/front/stadium/index.blade.php ENDPATH**/ ?>