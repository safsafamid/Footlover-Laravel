<?php

return [
    'Latest_News' => 'Dernières Nouvelles',
    'home' => 'Accueil',
    'players' => 'Joueurs',
    'players_list' => 'Liste des joueurs',
    'teams' => 'Équipes',
    'stadium' => 'Stade',

];
