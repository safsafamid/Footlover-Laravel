<?php

return [
    'Latest_News' => 'Dernières Nouvelles',
    'home' => 'Accueil',
    'players' => 'Joueurs',
    'teams' => 'Équipes',
    'stadium' => 'Stade',

];
