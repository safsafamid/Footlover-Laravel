<?php

return [
    'welcome' => 'This is a welcome message !',
];
