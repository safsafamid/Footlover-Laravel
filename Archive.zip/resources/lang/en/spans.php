<?php

return [
    'allow_images' => 'Allowed JPG, GIF or PNG. Max size of 800K',
    'select' => 'Select',
    'first_name' => 'First Name',
    'last_name' => 'Last Name',
    'full_name' => 'Full Name',
    'display_name' => 'Display Name',
    'shirt_number' => 'Shirt Number',
    'nationality' => 'Nationality',
    'birthdate' => 'Birth Date',
    'birthcountry' => 'Birth Country',
    'birthplace' => 'Birth Place',
    'team' => 'Team',
    'league' => 'League',
    'country' => 'Country',
    'position' => 'Position',
    'height' => 'Height',
    'weight' => 'Weight',
    'image' => 'Image',
];
