<?php

return [
    'full_name' => 'Full Name',
    'display_name' => 'Display Name',
    'shirt_number' => 'Shirt Number',
    'team' => 'Team',
    'image' => 'Image',
    'status' => 'Status',
    'actions' => 'Actions',
];
