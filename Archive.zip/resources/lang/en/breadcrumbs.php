<?php

return [
    'players' => 'Players',
    'player' => 'Player',
    'add_player' => 'Add Player',
    'players_list' => 'Players List',
    'teams' => 'Teams',
    'stadium' => 'Stadium',
];
