<?php

return [
    'add' => 'Add',
    'upload_new_photo' => 'Upload new photo',
    'reset' => 'Reset',
    'save_changes' => 'Save changes',
    'cancel' => 'Cancel',
];
