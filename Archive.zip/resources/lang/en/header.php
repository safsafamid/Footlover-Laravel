<?php

return [
    'Latest_News' => 'Latest News',
    'home' => 'Home',
    'players' => 'Players',
    'player' => 'Player',
    'players_list' => 'Players List',
    'teams' => 'Teams',
    'stadium' => 'Stadium',
];
