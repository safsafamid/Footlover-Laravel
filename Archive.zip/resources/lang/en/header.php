<?php

return [
    'Latest_News' => 'Latest News',
    'home' => 'Home',
    'players' => 'Players',
    'teams' => 'Teams',
    'stadium' => 'Stadium',
];
