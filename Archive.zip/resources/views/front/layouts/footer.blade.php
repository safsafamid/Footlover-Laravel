<footer id="ritekhela-footer" class="ritekhela-footer-one">

    <!--// Footer Widget //-->
    <div class="ritekhela-footer-widget">
        <div class="container">
            <div class="row">
                <aside class="widget col-md-4 widget_about_info">
                    <a href="index-2.html"><img src="{{asset('images/logo.png')}}" alt=""></a>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elUt ac malesuada ante.Sed gravida, ur quis tempus sollicitudin, tellus urna</p>
                    <div class="widget_about_info_social">
                        <a href="#" class="fab fa-facebook-f"></a>
                        <a href="#" class="fab fa-twitter"></a>
                        <a href="#" class="fab fa-dribbble"></a>
                        <a href="#" class="fab fa-linkedin-in"></a>
                        <a href="#" class="fab fa-youtube"></a>
                    </div>
                    <ul>
                        <li><i class="fa fa-map-marker-alt"></i> 9907 Salford road, east London Uk 2807</li>
                        <li><i class="fa fa-phone"></i> (+92) 123 45 678 - 987 65 432</li>
                        <li><i class="fa fa-envelope"></i> <a href="#">info@example.com</a></li>
                    </ul>
                </aside>
                <aside class="widget col-md-4 widget_twitter_feeds">
                    <div class="footer_widget_title"> <h2>Twitter Feeds</h2> </div>
                    <ul>
                        <li>
                            <i class="fab fa-twitter"></i>
                            <p>Sed gravida, urna quis tempus sollicitudin, tellus urnasuscipit nisl, id rhoncus ligula elit condimentum <a href="index-2.html" class="ritekhela-color">https://t.co/XHrPAM4ANv</a></p>
                            <time datetime="2008-02-14 20:00"><i class="fa fa-clock"></i> 2 Hours Ago</time>
                        </li>
                        <li>
                            <i class="fab fa-twitter"></i>
                            <p>Sed gravida, urna quis tempus sollicitudin, tellus urnasuscipit nisl, id rhoncus ligula elit condimentum <a href="index-2.html" class="ritekhela-color">https://t.co/XHrPAM4ANv</a></p>
                            <time datetime="2008-02-14 20:00"><i class="fa fa-clock"></i> 2 Hours Ago</time>
                        </li>
                    </ul>
                </aside>
                <aside class="widget col-md-4 widget_gallery">
                    <div class="footer_widget_title"> <h2>Flicker Photos</h2> </div>
                    <ul>
                        <li><a data-fancybox-group="group" href="extra-images/widget-gallery-1.jpg" class="fancybox"><img src="{{asset('extra-images/widget-gallery-1.jpg')}}" alt=""></a></li>
                        <li><a data-fancybox-group="group" href="extra-images/widget-gallery-1.jpg" class="fancybox"><img src="{{asset('extra-images/widget-gallery-2.jpg')}}" alt=""></a></li>
                        <li><a data-fancybox-group="group" href="extra-images/widget-gallery-1.jpg" class="fancybox"><img src="{{asset('extra-images/widget-gallery-3.jpg')}}" alt=""></a></li>
                        <li><a data-fancybox-group="group" href="extra-images/widget-gallery-1.jpg" class="fancybox"><img src="{{asset('extra-images/widget-gallery-4.jpg')}}" alt=""></a></li>
                        <li><a data-fancybox-group="group" href="extra-images/widget-gallery-1.jpg" class="fancybox"><img src="{{asset('extra-images/widget-gallery-5.jpg')}}" alt=""></a></li>
                        <li><a data-fancybox-group="group" href="extra-images/widget-gallery-1.jpg" class="fancybox"><img src="{{asset('extra-images/widget-gallery-6.jpg')}}" alt=""></a></li>
                        <li><a data-fancybox-group="group" href="extra-images/widget-gallery-1.jpg" class="fancybox"><img src="{{asset('extra-images/widget-gallery-7.jpg')}}" alt=""></a></li>
                        <li><a data-fancybox-group="group" href="extra-images/widget-gallery-1.jpg" class="fancybox"><img src="{{asset('extra-images/widget-gallery-8.jpg')}}" alt=""></a></li>
                    </ul>
                </aside>
            </div>
        </div>
    </div>
    <!--// Footer Widget //-->

    <!--// Footer CopyRight //-->
    <div class="ritekhela-copyright">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <p><a href="https://www.templateshub.net" target="_blank">Templates Hub</a></p>
                    <a href="#" class="ritekhela-back-top"><i class="fa fa-angle-up"></i></a>
                </div>
            </div>
        </div>
    </div>
    <!--// Footer CopyRight //-->

</footer>