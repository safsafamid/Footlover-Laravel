<div class="ritekhela-banner-one">
            
    <div class="ritekhela-banner-one-layer">
        <span class="ritekhela-banner-transparent"></span>
        <img src="{{asset('extra-images/banner-2.jpg')}}" alt="">
        <div class="ritekhela-banner-caption">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h1>We Are Developing <strong class="ritekhela-color">The Soccer</strong> Be Our Partner</h1>
                        <div class="clearfix"></div>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut ac malesuada ante Curabitur lacinia diam tempus tempor consectetur. Sed vitae dignissim purueget aliquam libero.</p>
                        <div class="clearfix"></div>
                        <a href="#" class="ritekhela-banner-btn">Read More</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="ritekhela-banner-one-layer">
        <span class="ritekhela-banner-transparent"></span>
        <img src="{{asset('extra-images/banner-1.jpg')}}" alt="">
        <div class="ritekhela-banner-caption">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h1>World Cup <strong class="ritekhela-color">rivalries</strong> reprised</h1>
                        <div class="clearfix"></div>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut ac malesuada ante Curabitur lacinia diam tempus tempor consectetur. Sed vitae dignissim purueget aliquam libero.</p>
                        <div class="clearfix"></div>
                        <a href="#" class="ritekhela-banner-btn">Read More</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>